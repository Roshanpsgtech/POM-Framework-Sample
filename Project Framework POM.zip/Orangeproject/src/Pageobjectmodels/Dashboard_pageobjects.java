package Pageobjectmodels;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Dashboard_pageobjects {

	@FindBy(id="react-burger-menu-btn")
	public static WebElement burgermenu;
	@FindBy(id="about_sidebar_link")
	public static WebElement About;
}
