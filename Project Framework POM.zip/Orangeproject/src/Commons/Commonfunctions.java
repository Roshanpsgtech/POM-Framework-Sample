package Commons;

import java.io.FileInputStream;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class Commonfunctions {
	public static Properties properties=null;
	public static WebDriver d=null;
	Logger logger =Logger.getLogger(Commonfunctions.class);
	public Properties loadPropertyFile() throws IOException
	{
		FileInputStream file=new FileInputStream("config.properties");
		properties=new Properties();
		properties.load(file);
		return properties;
	}
    @BeforeSuite
	public void openBrowser() throws IOException{
	PropertyConfigurator.configure("log4j.properties");
	logger.info("Swag labs Project started now..");
	logger.info("Loading the property file");
    	loadPropertyFile();
		String browser=properties.getProperty("browser");
		String url=properties.getProperty("url");
		String driverlocation=properties.getProperty("driverlocation");
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", driverlocation);
			logger.info("Launching Chrome");
		d = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", driverlocation);
			logger.info("Launching Firefox");
			 d = new FirefoxDriver();
		}
		d.manage().window().maximize();
		logger.info("Navigating to Application");
		d.get(url);
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    	
	}
    @AfterSuite
    public void closeBrowser()
    {
    	logger.info("Execution Done.Closing the Browser");
    }
}
