package Testcase;

import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Commons.Commonfunctions;
import Pageobjectmodels.Dashboard_pageobjects;
import Pageobjectmodels.Login_PageObjects;

public class Click_Myprofile extends Commonfunctions{
	Logger logger =Logger.getLogger(Click_Myprofile.class);
	@Test
	public void verifyformyprofile()
	{
		logger.info("Logging in to the Application");
		PageFactory.initElements(d, Login_PageObjects.class);
		Login_PageObjects.username.sendKeys(properties.getProperty("username"));
		Login_PageObjects.password.sendKeys(properties.getProperty("password"));
		Login_PageObjects.submit.click();
		
		PageFactory.initElements(d,Dashboard_pageobjects.class);
		Dashboard_pageobjects.burgermenu.click();
		Dashboard_pageobjects.About.click();
	}
}
